//
//  ViewController.swift
//  loginpage
//
//  Created by chetu on 12/29/23.
//

import UIKit

class ViewController: UIViewController {
  
    @IBOutlet weak var welcome: UILabel!
    @IBOutlet weak var text1: UITextField!
    @IBOutlet weak var text2: UITextField!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var gbtn: UIButton!
    @IBOutlet weak var Fbbtn: UIButton!
    @IBOutlet weak var label2: UILabel!
    
    @IBOutlet var bg_view: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        addgradientcolor()
        gesture()
    }
        @IBAction func click(_ sender: Any) {
            
            let user = UIStoryboard(name: "Main", bundle: nil)
            let ratna = user.instantiateViewController(withIdentifier: "VIEW2") as? VIEW2
            if let priya = ratna{
                priya.abc = "Log in Successfully"
                self.navigationController?.pushViewController(priya, animated: true)
        }
    }
        func addgradientcolor(){
            
            let gradient = CAGradientLayer()
            gradient.frame = view.bounds
            gradient.colors = [UIColor.black.cgColor,UIColor.systemBlue.cgColor]
            bg_view.layer.insertSublayer(gradient, at: 0)
        }
        private func gesture(){
        
            let ges = UIGestureRecognizer(target: self, action: #selector(ViewController.tapFunction))
            label2.isUserInteractionEnabled = true
            label2.addGestureRecognizer(ges)
        
        }
        @objc func tapFunction(sender:UITapGestureRecognizer){
            
            let screen = UIStoryboard(name: "Main", bundle: nil)
            let sc = screen.instantiateViewController(withIdentifier: "view3") as? view3
            if let tc = sc{
                
                self.navigationController?.pushViewController(tc, animated: true)
            }
        }
        
    }


