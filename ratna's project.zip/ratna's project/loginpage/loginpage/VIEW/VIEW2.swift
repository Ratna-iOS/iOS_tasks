//
//  VIEW2.swift
//  loginpage
//
//  Created by chetu on 12/29/23.
//

import UIKit

class VIEW2: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    var abc: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        label.text = "\(abc)"
        
    }
    

}
