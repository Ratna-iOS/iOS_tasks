//
//  view3.swift
//  loginpage
//
//  Created by chetu on 12/30/23.
//

import UIKit

class view3: UIViewController {

    @IBOutlet weak var labelr: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        labelr.text = "Reset Password"
    }
}
