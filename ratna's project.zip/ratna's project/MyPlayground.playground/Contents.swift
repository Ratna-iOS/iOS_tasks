import UIKit

//class Ratna{
//
//    func user() -> String {
//        var name = "ratna"
//        return name
//    }
//    func minAndmaxValue(array : [Int]) -> (minValue : Int, maxValue : Int) {
//
//        if (array.isEmpty) {return(0,0)}
//
//        var CurrentMinValue = array[0]
//        var CurrentMaxValue = array[0]
//
//        for value in array[1..<array.count]{
//            if value < CurrentMinValue {
//                CurrentMinValue = value
//            }else if value > CurrentMaxValue {
//                CurrentMaxValue = value
//            }
//        }
//        return(CurrentMinValue, CurrentMaxValue)
//    }
//}
//var priya = Ratna()
//priya.user()
//
//let Value = Ratna()
//let result = Value.minAndmaxValue(array: [10,33,56,78,36])
//print ("Min value = \(result.minValue) and Max value = \(result.maxValue)")




