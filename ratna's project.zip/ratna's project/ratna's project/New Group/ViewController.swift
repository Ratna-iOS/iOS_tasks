//
//  ViewController.swift
//  ratna's project
//
//  Created by chetu on 12/21/23.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    @IBOutlet weak var Text1: UITextField!
    @IBOutlet weak var Text2: UITextField!
    @IBOutlet weak var Text3: UITextField!
    @IBOutlet weak var Button: UIButton!
    @IBOutlet weak var Label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        add()
        unwrappOptional()
    }
    
    func add() {
        Text1.placeholder = "Enter First Value"
        Text2.placeholder = "Enter Second Value"
        Text3.placeholder = "Enter Third Value"
        
        self.Button.setTitle("Update label", for: .normal)
    }
    
    @IBAction func Action(_ sender: Any) {
        
       let Text11 = Int(Text1.text ?? "")
       let Text22 = Int(Text1.text ?? "")
       let Text33 = Int(Text1.text ?? "")
        
        guard let Text11 else {
            return
        }
        guard let Text22 else {
            return
        }
        guard let Text33 else {
            return
        }
       let res = Text11 + Text22 + Text33
        
        self.Label.text = "\(res)"
        
        let button : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let nextVC = button.instantiateViewController(identifier: "ViewController2") as? ViewController2
        
        if let vc = nextVC {
            vc.title = "View_2"
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    var optionalName : String?
    var nonoptionalName : String = ""
    
    func unwrappOptional(){
        self.Label.text = optionalName
        
        if let ddf = optionalName {
            self.nonoptionalName = ddf
        }
        guard let dd = optionalName else {
            return
        }
        self.Label.text = self.nonoptionalName
    }
}

