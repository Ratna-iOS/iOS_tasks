//
//  ViewController2.swift
//  ratna's project
//
//  Created by chetu on 12/27/23.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backgroundColor = .red
       
    }
}
