//
//  secondViewController.swift
//  task1
//
//  Created by chetu on 1/6/24.
//

import UIKit

protocol move{
    func backmove(data : String)
}

class secondViewController: UIViewController {
    
    var delegate : move!
    
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var text2: UITextField!
    @IBOutlet weak var text1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func action(_ sender: Any) {
        
        let a = Int(text1.text ?? "")
        let b = Int(text2.text ?? "")
        
        guard let c = a else{
            return
        }
        guard let d = b else {
            return
        }
        let sum = c + d
        
        delegate.backmove(data: "\(sum)")
        navigationController?.popViewController(animated: true)
    }
}
