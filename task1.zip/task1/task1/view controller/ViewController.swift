//
//  ViewController.swift
//  task1
//
//  Created by chetu on 1/6/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func btnclick(_ sender: Any) {
        
        let abc = UIStoryboard(name: "Main", bundle: nil)
        let nextvc = abc.instantiateViewController(withIdentifier: "secondViewController") as? secondViewController
        // use delegate
        nextvc?.delegate = self
        //yahan tak - ye wali important n
        if let vc = nextvc {
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
}
//calling of protocol
extension ViewController : move
{
    func backmove(data: String) {
        label.text = data
    }
}
